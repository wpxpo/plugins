<?php
/*
 * Plugin Name:       XpoKit 
 * Plugin URI:        https://www.wpxpo.com/
 * Description:       Xpo Kit Plugin
 * Version: 		  1.0.0
 * Author:            wpxpo.com
 * Author URI:        https://wpxpo.com/
 * Text Domain:       xpokit
 * Requires at least: 5.0
 * Tested up to: 	  5.2
 * License:           GPL-2.0+
 * License URI:       http://www.gnu.org/licenses/gpl-2.0.txt
 * Domain Path:       /languages
 */

defined( 'ABSPATH' ) || exit;

define( 'XPO_VERSION', '1.0.0' );
define( 'XPO_URL', plugin_dir_url(__FILE__) );
define( 'XPO_PATH', plugin_dir_path(__FILE__) );

// Language Load
add_action( 'init', 'xpo_language_load');
function xpo_language_load(){
    load_plugin_textdomain( 'xpokit', false,  basename(dirname(__FILE__)).'/languages/' );
}

if (!function_exists('xpo_functions')) {
    function xpo_functions(){
        require_once XPO_PATH . 'core/Functions.php';
        return new \XPO\Functions();
    }
}


if (!class_exists('Xpo_Base')) {
    require_once XPO_PATH . 'core/Base.php';
    new \XPO\Base();
}