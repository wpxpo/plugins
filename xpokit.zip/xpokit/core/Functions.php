<?php
namespace XPO;

defined( 'ABSPATH' ) || exit;

if (!class_exists('Functions')) {
    class Functions{
       
        /**
		 * @since v.1.0.0
		 * @return trimed excerpt
		 */
        public function excerpt( $post_id, $word = 55 ) {
            $post_content = apply_filters( 'the_content', get_post_field( 'post_content', $post_id ) );
            return apply_filters( 'the_excerpt', wp_trim_words( $post_content, $word ) );
        }
        
        /**
		 * @since v.1.0.0
		 * @return all_taxonomy_list
		 */
        public function taxonomy( $taxonomy = 'category', $hide_empty = false ) {
            $data = array();
            $tax = get_terms(array('taxonomy' => $taxonomy, 'hide_empty' => $hide_empty));
            if (!empty($tax)) {
                foreach ($tax as $val) {
                    $data[] = array('value' => $val->slug, 'name' => $val->name);
                }
            }
        }


    }
}