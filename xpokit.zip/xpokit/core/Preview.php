<?php
namespace XPO;

defined('ABSPATH') || exit;

class Preview{
    
    public function __construct(){
        add_action( 'admin_menu', array( $this, 'demo_importer_menu' ), 9 );
    }

    public function demo_importer_menu() {
        $demo_page = add_theme_page( __( 'Demo Importer', 'xpokit' ), __( 'Demo Importer', 'xpokit' ), 'switch_themes', 'theme-importer', array( $this, 'demo_importer' ) );

        add_action( 'load-' . $demo_page, array( $this, 'load_admin_js') );
    }

    public function load_admin_js(){
        add_action( 'admin_enqueue_scripts', array( $this, 'enqueue_admin_js' ) );
    }

    public function enqueue_admin_js(){
        wp_enqueue_script( 'my-script', XPO_URL . 'assets/js/importer.js', array( 'jquery' ) );
    }

    public function demo_importer() { ?>
        <div class="wp-filter hide-if-no-js"><h1>This Demo List</h1></div>
        <div class="theme-browser content-filterable rendered">

            <div class="theme" tabindex="0" aria-describedby="colormag-free-action colormag-free-name" data-slug="colormag-free">
                <div class="theme-screenshot">
                    <img src="https://raw.githubusercontent.com/themegrill/themegrill-demo-pack/master/resources/colormag/colormag-free/screenshot.jpg" alt="">
                </div>
                <div class="theme-author">By ThemeGrill</div>
                <div class="theme-id-container">
                    <h2 class="theme-name" id="colormag-free-name">ColorMag</h2>
                    <div class="theme-actions">	
                        <a class="button button-primary hide-if-no-js demo-import" href="#" data-name="ColorMag" data-slug="colormag-free" aria-label="Import ColorMag" data-plugins="{&quot;everest-forms&quot;:{&quot;name&quot;:&quot;Everest Forms&quot;,&quot;slug&quot;:&quot;everest-forms/everest-forms.php&quot;,&quot;is_active&quot;:false,&quot;is_install&quot;:false}}">Import</a>
                        <button class="button preview install-demo-preview">Preview</button>
                    </div>
                </div>
            </div>

            <div class="theme" tabindex="0" aria-describedby="colormag-free-action colormag-free-name" data-slug="colormag-free">
                <div class="theme-screenshot">
                    <img src="https://raw.githubusercontent.com/themegrill/themegrill-demo-pack/master/resources/colormag/colormag-free/screenshot.jpg" alt="">
                </div>
                <div class="theme-author">By ThemeGrill</div>
                <div class="theme-id-container">
                    <h2 class="theme-name" id="colormag-free-name">ColorMag</h2>
                    <div class="theme-actions">	
                        <a class="button button-primary hide-if-no-js demo-import" href="#" data-name="ColorMag" data-slug="colormag-free" aria-label="Import ColorMag" data-plugins="{&quot;everest-forms&quot;:{&quot;name&quot;:&quot;Everest Forms&quot;,&quot;slug&quot;:&quot;everest-forms/everest-forms.php&quot;,&quot;is_active&quot;:false,&quot;is_install&quot;:false}}">Import</a>
                        <button class="button preview install-demo-preview">Preview</button>
                    </div>
                </div>
            </div>
        </div>




        <!-- ################################### -->
        <!-- ######## New Themes Start ######### -->
        <!-- ################################### -->
        <div class="theme-install-overlay wp-full-overlay expanded iframe-ready" style="display:block;">
            <div class="wp-full-overlay-sidebar">
                <div class="wp-full-overlay-header">
                    <button class="close-full-overlay"><span class="screen-reader-text">Close</span></button>
                    <button class="previous-theme"><span class="screen-reader-text">Previous</span></button>
                    <button class="next-theme"><span class="screen-reader-text">Next</span></button>
                    <a class="button button-primary hide-if-no-js demo-import" href="#" data-name="ColorMag Beauty Blog" data-slug="colormag-beauty-blog">Import Demo</a>
                </div>
                <div class="wp-full-overlay-sidebar-content">
                    <div class="install-theme-info">
                        <h3 class="theme-name">ColorMag Beauty Blog</h3>
                        <span class="theme-by">By ThemeGrill</span>
                        <img class="theme-screenshot" src="https://raw.githubusercontent.com/themegrill/themegrill-demo-pack/master/resources/colormag/colormag-beauty-blog/screenshot.jpg" alt="">
                        <div class="theme-details">
                            <div class="theme-version">Version: 1.0.0</div>
                            <div class="theme-description">You can use this ColorMag demo for your Beauty Blogs.</div>
                        </div>

                        <div class="plugins-details">
                            <h4 class="plugins-info">Plugins Information</h4>
                            <table class="plugins-list-table widefat striped">
                                <thead>
                                    <tr>
                                        <th scope="col" class="manage-column required-plugins" colspan="2">Required Plugins</th>
                                    </tr>
                                </thead>
                                <tbody id="the-list">
                                    <tr class="plugin" data-slug="elementor" data-plugin="elementor/elementor.php" data-name="Elementor">
                                        <td class="plugin-name">
                                            <a href="https://wordpress.org/plugins/elementor" target="_blank">Elementor</a>
                                        </td>
                                        <td class="plugin-status">
                                            
                                                <span class="active"></span>
                                            
                                        </td>
                                    </tr>
                                    <tr class="plugin inactive" data-slug="everest-forms" data-plugin="everest-forms/everest-forms.php" data-name="Everest Forms">
                                        <td class="plugin-name">
                                            <a href="https://wordpress.org/plugins/everest-forms" target="_blank">Everest Forms</a>
                                        </td>
                                        <td class="plugin-status">
                                            <span class="install-now"></span>
                                        </td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
                <div class="wp-full-overlay-footer">
                    <div class="demo-import-actions">
                        <a class="button button-hero button-primary hide-if-no-js demo-import" href="#" data-name="ColorMag Beauty Blog" data-slug="colormag-beauty-blog">Import Demo</a>
                    </div>
                    <button type="button" class="collapse-sidebar button" aria-expanded="true" aria-label="Collapse Sidebar">
                        <span class="collapse-sidebar-arrow"></span>
                        <span class="collapse-sidebar-label">Collapse</span>
                    </button>
                    <div class="devices-wrapper">
                        <div class="devices">
                            <button type="button" class="preview-desktop active" aria-pressed="true" data-device="desktop">
                                <span class="screen-reader-text">Enter desktop preview mode</span>
                            </button>
                            <button type="button" class="preview-tablet" aria-pressed="false" data-device="tablet">
                                <span class="screen-reader-text">Enter tablet preview mode</span>
                            </button>
                            <button type="button" class="preview-mobile" aria-pressed="false" data-device="mobile">
                                <span class="screen-reader-text">Enter mobile preview mode</span>
                            </button>
                        </div>
                    </div>
                </div>
            </div>
            <div class="wp-full-overlay-main">
                <iframe src="http://demo.themegrill.com/colormag-beauty-blog/" title="Preview"></iframe>
            </div>
        </div>
        <!-- ################################### -->
        <!-- ######## New Themes Stop ########## -->
        <!-- ################################### -->



    <? }
}