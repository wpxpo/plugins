<?php
defined('ABSPATH') || exit;

if( !class_exists( 'WP_Customize_Control' ) ){
	return null;
}

class Xpo_Rgba_Control extends WP_Customize_Control {

	public $type = 'rgba';
	public $palette;
	public $show_opacity;

	public function enqueue() {
		wp_enqueue_script( 'alpha-color-picker-js', XPO_URL . 'assets/js/alpha-color-picker.js', array( 'jquery', 'wp-color-picker' ), XPO_VERSION, true );
		wp_enqueue_style( 'alpha-color-picker-css', XPO_URL . 'assets/css/alpha-color-picker.css', array( 'wp-color-picker' ), XPO_VERSION );
	}

	public function render_content() {
		if ( is_array( $this->palette ) ) {
			$palette = implode( '|', $this->palette );
		} else {
			$palette = ( false === $this->palette || 'false' === $this->palette ) ? 'false' : 'true';
		}
		$show_opacity = ( false === $this->show_opacity || 'false' === $this->show_opacity ) ? 'false' : 'true'; 
		?>
		<div class="xpo-customizer-warp">
			<?php if ( isset( $this->label ) && '' !== $this->label ): ?>
				<span class="customize-control-title"><?php echo sanitize_text_field( $this->label ); ?></span>
			<?php endif; ?>
			<div class="xpo-customizer-rgba">
				<input class="alpha-color-control" type="text" data-show-opacity="<?php echo $show_opacity; ?>" data-palette="<?php echo esc_attr( $palette ); ?>" data-default-color="<?php echo esc_attr( $this->settings['default']->default ); ?>" <?php $this->link(); ?>  />
			</div>
		</div>
	<?php }
}