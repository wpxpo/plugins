<?php
defined('ABSPATH') || exit;

if( !class_exists( 'WP_Customize_Control' ) ){
	return null;
}

class Xpo_Layout_Control extends WP_Customize_Control {

	public $type = 'layout';
	public $key;
	public $options;
	public $depends;

	public function render_content() {
		?>
		<?php if( $this->depends ){ ?>
			<div class="xpo-customizer-warp xpo-layout" data-condition="<?php echo $this->depends; ?>" data-value="<?php echo $this->value(); ?>">
		<?php } else { ?>
			<div class="xpo-customizer-warp">
		<?php } ?>
			<?php if ( isset( $this->label ) && '' !== $this->label ): ?>
				<span class="customize-control-title"><?php echo sanitize_text_field( $this->label ); ?></span>
			<?php endif; ?>
			<div class="xpo-customizer-layout">
				<?php foreach ($this->options as $key => $val) { ?>
						<label for="<?php echo esc_attr($key); ?>"><img src="<?php echo esc_url($val); ?>" /></label>
						<input  <?php $this->link(); ?> name="<?php echo $this->key; ?>" type="radio" id="<?php echo esc_attr($key); ?>" value="<?php echo esc_attr($key); ?>" <?php checked( $this->value(), $key ); ?> />
				<?php } ?>
			</div>
		</div>
	<?php }
}

