<?php
defined('ABSPATH') || exit;

if( !class_exists( 'WP_Customize_Control' ) ){
	return null;
}

class Xpo_Switch_Control extends WP_Customize_Control {

	public $type = 'checkbox';
	public $depends;

	public function render_content(){
	?>
		<?php if( $this->depends ){ ?>
			<div class="xpo-customizer-warp xpo-checkbox" data-condition="<?php echo $this->depends; ?>" data-value="<?php echo $this->value(); ?>">
		<?php } else { ?>
			<div class="xpo-customizer-warp">
		<?php } ?>
			<?php if( isset($this->label) && '' !== $this->label ): ?>
				<span class="customize-control-title"><?php echo sanitize_text_field($this->label); ?></span>
			<?php endif; ?>
			<div class="xpo-customizer-switch">
				<input class="<?php echo $this->depends ? 'xpo-checkbox-change' : ''; ?>" type="checkbox" <?php checked( $this->value(), 1 ); ?> <?php $this->link(); ?> >
			</div>
		</div>
	<?php
	}
}