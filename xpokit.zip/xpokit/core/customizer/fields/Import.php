<?php
defined('ABSPATH') || exit;

if( class_exists( 'WP_Customize_Control' ) && !class_exists( 'Xpo_Import_Control' ) ){
    return null;
}

class Xpo_Import_Control extends WP_Customize_Control {
    
    public $type = 'import';

    public function render_content() { ?>
        <div class="xpo-customizer-warp">
            <?php if ( isset( $this->label ) && '' !== $this->label ): ?>
				<span class="customize-control-title"><?php echo sanitize_text_field( $this->label ); ?></span>
			<?php endif; ?>
            <div class="xpo-customizer-import">
                <input type="file" id="xpo-import-data-file"/>
                <button type="button" id="xpo-import-data" class="button"><?php _e('Import', 'xpokit'); ?></button>
                <div class="xpo-import-status" id="xpo-import-status"></div>
            </div>
        </div>
        <?php
    }
}
