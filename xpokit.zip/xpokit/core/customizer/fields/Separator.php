<?php
defined('ABSPATH') || exit;

if( !class_exists( 'WP_Customize_Control' ) ){
	return null;
}

class Xpo_Separator_Control extends WP_Customize_Control {
	
	public $type = 'separator';
	
	public function render_content(){
	?>
		<div class="xpo-customizer-warp">
			<?php if( isset($this->label) && '' !== $this->label ): ?>
				<span class="customize-control-title"><?php echo sanitize_text_field($this->label); ?></span>
			<?php endif; ?>
			<div class="xpo-customizer-separator">
				<hr/>
			</div>
		</div>
	<?php
	}
}
