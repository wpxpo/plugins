<?php
defined('ABSPATH') || exit;

if( class_exists( 'WP_Customize_Control' ) && !class_exists( 'Xpo_Social_Control' ) ){
    return null;
}

class Xpo_Social_Control extends WP_Customize_Control {
    
    public $type = 'social';

    public function enqueue() {
		wp_enqueue_script( 'xpo-social-js', XPO_URL . 'assets/js/wpxpo-social.js', array( 'jquery' ), XPO_VERSION, true );
	}
    
    public function render_content() {
        $social = ['facebook','twitter','dribbble','pinterest','github','instagram','tumblr','flickr'];
        ?>
        <div class="xpo-customizer-warp">
            <?php if ( isset( $this->label ) && '' !== $this->label ): ?>
				<span class="customize-control-title"><?php echo sanitize_text_field( $this->label ); ?></span>
			<?php endif; ?>
            <div class="xpo-customizer-social">
                <input class="xpo-customizer-social" <?php $this->link(); ?> type="text" value="<?php echo $this->value(); ?>" />

                <div class="xpo-repeatable-field">
                    <select class="xpo-field-social-class">
                        <?php
                        foreach ($social as $val) {
                            echo '<option'.($val==$this->value()?' selected':'').'>'.$val.'</option>';
                        }
                        ?>
                    </select>
                    <input class="xpo-field-social-url" value=""/>
                </div>

                <button class="xpo-field-social-add"><?php _e('+ Add New'); ?></button>
            </div>
        </div>
        <?php
    }
}
