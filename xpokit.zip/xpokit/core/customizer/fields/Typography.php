<?php
defined('ABSPATH') || exit;

if( class_exists( 'WP_Customize_Control' ) && !class_exists( 'Xpo_Typography_Control' ) ){
    return null;
}

class Xpo_Typography_Control extends WP_Customize_Control {
    
    public $type = 'typography';

    public function enqueue() {
		wp_enqueue_script( 'xpo-typography-js', XPO_URL . 'assets/js/xpo-typography.js', array( 'jquery' ), XPO_VERSION, true );
	}
    
    public function render_content() { ?>
        <div class="xpo-customizer-warp">
            <?php if ( isset( $this->label ) && '' !== $this->label ): ?>
				<span class="customize-control-title"><?php echo sanitize_text_field( $this->label ); ?></span>
			<?php endif; ?>
            <div class="xpo-customizer-typography">
                <input class="xpo-customizer-typography-input" <?php $this->link(); ?> type="text" value="<?php echo $this->value(); ?>" />
                <select class="xpo-field-typography-field"></select>
                <select class="xpo-field-typography-weight-field"></select>
            </div>
        </div>
        <?php
    }
}
