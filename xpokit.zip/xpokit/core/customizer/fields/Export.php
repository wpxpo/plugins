<?php
defined('ABSPATH') || exit;

if( class_exists( 'WP_Customize_Control' ) && !class_exists( 'Xpo_Export_Control' ) ){
    return null;
}

class Xpo_Export_Control extends WP_Customize_Control {
    
    public $type = 'export';
    
    public function render_content() { ?>
        <div class="xpo-customizer-warp">
            <?php if ( isset( $this->label ) && '' !== $this->label ): ?>
				<span class="customize-control-title"><?php echo sanitize_text_field( $this->label ); ?></span>
			<?php endif; ?>
            <div class="xpo-customizer-export">
                <button type="button" id="xpo-export-data" class="button"><?php _e('Export', 'xpokit'); ?></button>
            </div>
        </div>
        <?php
    }
}