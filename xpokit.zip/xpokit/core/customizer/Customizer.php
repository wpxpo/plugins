<?php
// namespace XPO;

defined('ABSPATH') || exit;

if (! class_exists('Customizer')) {
    class Customizer{

        public function __construct(){
            add_action( 'customize_register', array($this, 'customizer_generator') );
            add_action( 'wp_ajax_xpo_export_data', array( $this, 'export_callback') );
            add_action( 'wp_ajax_xpo_import_data', array( $this, 'import_callback') );        
        }

        public function export_callback() {
            $slug = get_option( 'stylesheet' );
            $data = get_option( "theme_mods_$slug" );
            header( "Content-Description: File Transfer" );
            header( "Content-Disposition: attachment; filename=theme_customizer_data.json" );
            header( "Content-Type: application/octet-stream" );
            echo json_encode($data);
            exit;
        }

        public function import_callback(){
            $theme_data = file_get_contents($_FILES['file']['tmp_name']);

            if (empty($theme_data)) {
                echo 0;
                exit();
            }

            $theme_data = json_decode($theme_data, true);

            if (empty($theme_data)) {
                echo 0;
                exit();
            }

            unset($theme_data['nav_menu_locations']);
            $theme_slug = get_option( 'stylesheet' );
            $mods = get_option( "theme_mods_$theme_slug" );

            if ($mods  === false) {
                $status = add_option( "theme_mods_$theme_slug", $theme_data );
                echo $status ? 1 : 0;
            } else {
                $theme_data['nav_menu_locations'] = $mods['nav_menu_locations'];
                $status = update_option( "theme_mods_$theme_slug", $theme_data );
                echo $status ? 1 : 0;
            }
            exit();
        }

        public function customizer_generator( $wp_customize ){

            require_once XPO_PATH . 'core/customizer/fields/Rgba.php';
            require_once XPO_PATH . 'core/customizer/fields/Separator.php';
            require_once XPO_PATH . 'core/customizer/fields/Switch.php';
            require_once XPO_PATH . 'core/customizer/fields/Layout.php';
            require_once XPO_PATH . 'core/customizer/fields/Import.php';
            require_once XPO_PATH . 'core/customizer/fields/Export.php';
            require_once XPO_PATH . 'core/customizer/fields/Typography.php';
            require_once XPO_PATH . 'core/customizer/fields/Select.php';

            $prams = apply_filters( 'xpokit_customizer', array() );

            if( is_array( $prams ) ){
                foreach ( $prams as $panel ) {
                    // Panel
                    $wp_customize->add_panel( $panel['key'], array(
                        'title'    => $panel['title'],
                        'priority' => isset($panel['priority']) ? $panel['priority'] : 10,
                    ) );
                    foreach ( $panel['options'] as $section ) {
                        // Section
                        $wp_customize->add_section( $section['key'], array(
                            'title'   => $section['title'],
                            'panel'   => $panel['key'],
                        ));
                        foreach ( $section['options'] as $fields ) { 
                            switch ($fields['type']) {

                                case 'text':
                                    $wp_customize->add_setting( $fields['key'], array(
                                        'default'   => isset( $fields['default'] ) ? $fields['default'] : '',
                                    ));
                                    $wp_customize->add_control( $fields['key'], array(
                                        'type'      => 'text',
                                        'section'   => $section['key'],
                                        'label'     => $fields['title'],
                                    ));
                                    break;
            
                                case 'textarea':
                                    $wp_customize->add_setting( $fields['key'], array(
                                        'default'   => isset( $fields['default'] ) ? $fields['default'] : '',
                                    ));
                                    $wp_customize->add_control( $fields['key'], array(
                                        'type'      => 'textarea',
                                        'section'   => $section['key'],
                                        'label'     => $fields['title'],
                                    ));
                                    break;
            
                                case 'email':
                                    $wp_customize->add_setting( $fields['key'], array(
                                        'default'   => isset( $fields['default'] ) ? $fields['default'] : '',
                                    ));
                                    $wp_customize->add_control( $fields['key'], array(
                                        'type'      => 'email',
                                        'label'     => $fields['title'],
                                        'section'   => $section['key'],
                                    ));
                                    break;
            
                                case 'select':
                                    $wp_customize->add_setting( $fields['key'], array(
                                        'default' => isset( $fields['default'] ) ? $fields['default'] : '',
                                    ));
                                    $wp_customize->add_control( new Xpo_Select_Control( $wp_customize, $fields['key'], array(
                                        'label'     => $fields['title'],
                                        'section'   => $section['key'],
                                        'options'   => $fields['options'],
                                        'depends'   => isset($fields['depends']) ? $fields['depends'] : '',
                                    )));
                                    break;
            
                                case 'color':
                                    $wp_customize->add_setting( $fields['key'], array(
                                        'default' => isset( $fields['default'] ) ? $fields['default'] : '',
                                    ));
                                    $wp_customize->add_control( $fields['key'], array(
                                        'type'      => 'color',
                                        'section'   => $section['key'],
                                        'label'     => $fields['title'],
                                    ));
                                    break;
            
                                case 'separator':
                                    $wp_customize->add_setting( $fields['key'], array() );
                                    $wp_customize->add_control( new Xpo_Separator_Control( $wp_customize, $fields['key'], array(
                                        'label'     => $fields['title'],
                                        'section'   => $section['key'],
                                    )));
                                    break;
            
                                case 'number':
                                    $wp_customize->add_setting( $fields['key'], array(
                                        'default'   => isset( $fields['default'] ) ? $fields['default'] : '',
                                    ));
                                    $wp_customize->add_control( $fields['key'], array(
                                        'type'      => 'number',
                                        'label'     => $fields['title'],
                                        'section'   => $section['key'],
                                    ));
                                    break;
            
                                case 'date':
                                    $wp_customize->add_setting( $fields['key'], array(
                                        'default' => isset( $fields['default'] ) ? $fields['default'] : '',
                                    ));
                                    $wp_customize->add_control( $fields['key'], array(
                                        'type'    => 'date',
                                        'label'   => $fields['title'],
                                        'section' => $section['key'],
                                    ));
                                    break;
            
                                case 'switch':
                                    $wp_customize->add_setting( $fields['key'], array(
                                        'default' => isset( $fields['default'] ) ? $fields['default'] : '',
                                    ));
                                    $wp_customize->add_control( new Xpo_Switch_Control( $wp_customize, $fields['key'], array(
                                        'label'   => $fields['title'],
                                        'section' => $section['key'],
                                        'settings' => $fields['key'],
                                        'depends' => isset($fields['depends']) ? $fields['depends'] : '',
                                    )));
                                    break;
            
                                case 'media':
                                    $wp_customize->add_setting( $fields['key'], array(
                                        'default' => isset( $fields['default'] ) ? $fields['default'] : '',
                                    ));
                                    $wp_customize->add_control( new WP_Customize_Image_Control( $wp_customize, $fields['key'], array(
                                        'label'   => $fields['title'],
                                        'section' => $section['key'],
                                    )));
                                    break;
                                
                                case 'rgba':
                                    $wp_customize->add_setting( $fields['key'], array(
                                        'default' => isset( $fields['default'] ) ? $fields['default'] : '',
                                    ));
                                    $wp_customize->add_control( new Xpo_Rgba_Control( $wp_customize, $fields['key'], array(
                                        'label'         => $fields['title'],
                                        'section'       => $section['key'],
                                        'show_opacity'  => true,
                                    )));
                                    break;
            
                                case 'layout':
                                    $wp_customize->add_setting( $fields['key'], array(
                                        'default' => isset( $fields['default'] ) ? $fields['default'] : '',
                                    ));
                                    $wp_customize->add_control( new Xpo_Layout_Control( $wp_customize, $fields['key'], array(
                                        'label'     => $fields['title'],
                                        'key'       => $fields['key'],
                                        'section'   => $section['key'],
                                        'options'   => $fields['options'],
                                        'depends'   => isset($fields['depends']) ? $fields['depends'] : '',
                                    )));
                                    break;

                                case 'typography':
                                    $wp_customize->add_setting( $fields['key'], array(
                                        'default' => isset( $fields['default'] ) ? $fields['default'] : '',
                                    ));
                                    $wp_customize->add_control( new Xpo_Typography_Control( $wp_customize, $fields['key'], array(
                                        'label'         => $fields['title'],
                                        'section'       => $section['key'],
                                    )));
                                    break;

                                case 'export':
                                    $wp_customize->add_setting( $fields['key'], array() );
                                    $wp_customize->add_control( new Xpo_Export_Control( $wp_customize, $fields['key'], array(
                                        'label'     => $fields['title'],
                                        'section'   => $section['key'],
                                    )));
                                    break;

                                case 'import':
                                    $wp_customize->add_setting( $fields['key'], array() );
                                    $wp_customize->add_control( new Xpo_Import_Control( $wp_customize, $fields['key'], array(
                                        'label'     => $fields['title'],
                                        'section'   => $section['key'],
                                    )));
                                    break;

                                default:
                                    # code...
                                    break;
                            }
                        }
                    }
                }
            }
        }
    }
    new Customizer();
}

