<?php
defined('ABSPATH') || exit;

// Call in Theme Function
function xpokit_customizer_callback($prams) {
	$new_prams = array(
        array(
            'key'     => 'stabon_options',
            'type'    => 'panel',
            'priority'=> 10,
            'title'   => __( 'Stabon Theme Options', 'xpokit' ),
            'options' => array(
                array(
                    'key'    => 'stabon_section',
                    'type'   => 'section',
                    'title'  => __( 'TD Theme Options', 'xpokit' ),
                    'options'=> array(

                        array(
                            'key'     => 'stabon_text',
                            'type'    => 'text',
                            'title'   => __( '01. Text Label', 'xpokit' ),
                            'default' => 'Text Default Content',
                        ),
                        array(
                            'key'     => 'stabon_textarea',
                            'type'    => 'textarea',
                            'title'   => __( '02. TextArea Label', 'xpokit' ),
                            'default' => 'TextArea Content',
                        ),
                        array(
                            'key'     => 'stabon_email',
                            'type'    => 'email',
                            'title'   => __( '03. Email Label', 'xpokit' ),
                            'default' => 'anik@gmail.com',
                        ),
                        array(
                            'key'     => 'stabon_select',
                            'type'    => 'select',
                            'title'   => __( '04. Select Label', 'xpokit' ),
                            'default' => 'cerulean',
                            'options'   => array(
                                'default'   => __('Default', 'xpokit'),
                                'cerulean'  => __('Cerulean', 'xpokit'),
                                'cerulean22'  => __('Cerulean 22', 'xpokit'),
                            ),
                            //'depends' => 'stabon_email#=#cerulean'
                        ),
                        array(
                            'key'     => 'stabon_separator',
                            'type'    => 'separator',
                            'title'   => __( '05. Separator Label', 'xpokit' ),
                        ),
                        array(
                            'key'     => 'stabon_number',
                            'type'    => 'number',
                            'title'   => __( '06. Number Label', 'xpokit' ),
                            'default' => 12,
                        ),
                        array(
                            'key'     => 'stabon_color',
                            'type'    => 'color',
                            'title'   => __( '07. Color Label', 'xpokit' ),
                            'default' => '#ccc',
                        ),
                        array(
                            'key'     => 'stabon_date',
                            'type'    => 'date',
                            'title'   => __( '08. Date Label', 'xpokit' ),
                            'default' => '2020-08-09',
                        ),
                        array(
                            'key'     => 'stabon_switch',
                            'type'    => 'switch',
                            'title'   => __( '09. Switch Label', 'xpokit' ),
                            'default' => 1,
                            //'depends' => 'stabon_date#=#1'
                        ),
                        array(
                            'key'     => 'stabon_medias',
                            'type'    => 'media',
                            'title'   => __( '10. Media Label', 'xpokit' ),
                            'default' => XPO_URL . 'assets/img/sample_image.png',
                        ),
                        array(
                            'key'     => 'stabon_rgba',
                            'type'    => 'rgba',
                            'title'   => __( '11. Rgba Label', 'xpokit' ),
                            'default' => 'rgba(209,0,55,0.7)',
                        ),
                        array(
                            'key'     => 'stabon_layout',
                            'type'    => 'layout',
                            'title'   => __( '12. Layout Labels', 'xpokit' ),
                            'default' => 'two',
                            'options' => array(
                                'one'   => 'https://via.placeholder.com/140x100',
                                'two'   => 'https://via.placeholder.com/140x100',
                                'three' => 'https://via.placeholder.com/140x100',
                            ),
                            //'depends' => 'stabon_rgba#=#two'
                        ),
                        array(
                            'key'     => 'stabon_typography',
                            'type'    => 'typography',
                            'title'   => __( '13. Typography Label', 'xpokit' ),
                            'default' => 'Georgia#sans-serif#400',
                        ),
                    )
				),
				array(
                    'key'    => 'stabon_export_import',
                    'type'   => 'section',
                    'title'  => __( 'Export/Import', 'xpokit' ),
					'options'=> array(
						array(
                            'key'     => 'stabon_export',
							'type'    => 'export',
                            'title'   => __( 'Export', 'xpokit' ),
                            'default' => 'Text Default Content',
						),
						array(
                            'key'     => 'stabon_Import',
							'type'    => 'import',
                            'title'   => __( 'Import', 'xpokit' ),
                            'default' => 'Text Default Content',
                        ),
					)
				) // export-import
            )
        )
    );

	return array_merge($new_prams, $prams);
}
add_filter('xpokit_customizer', 'xpokit_customizer_callback'); 