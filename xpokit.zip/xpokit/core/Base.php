<?php
namespace XPO;

defined( 'ABSPATH' ) || exit;

class Base{

	public function __construct(){
		$this->includes();
		add_action( 'customize_controls_enqueue_scripts', array( $this, 'customizer_controls_scripts' ) );
	}

	/**
	 * * @since v.1.0.0
	 * Customizer Init 
	 * @customizer
	 */
	public function includes(){
		require_once XPO_PATH . 'core/customizer/Customizer.php';
	}
	
	/**
	 * @since v.1.0.0
	 * Customizer Assets Enqueue
	 */
	public function customizer_controls_scripts() {
		wp_enqueue_style( 'xpo-customizer-css', XPO_URL . 'assets/css/xpo-customizer.css', array(), XPO_VERSION, false );
		wp_enqueue_script( 'xpo-customizer-js', XPO_URL . 'assets/js/xpo-customizer.js', array('jquery'), XPO_VERSION, false );

		wp_localize_script( 'xpo-customizer-js', 'xpo_kit', array(
			'ajax_url' 		 => admin_url('admin-ajax.php'),
			'import_success' => esc_html__('Success! Your theme data successfully imported. Page will be reloaded within 2 sec.', 'xpokit'),
			'import_error'   => esc_html__('Error! Your theme data importing failed.', 'xpokit'),
			'file_error' 	 => esc_html__('Error! Please upload a file.', 'xpokit')
		));
	}
}