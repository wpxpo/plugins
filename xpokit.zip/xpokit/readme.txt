=== XpoKit ===
Contributors: wpxpo
Tags: customizer, font, fieldtype, theme
Requires at least: 4.0
Tested up to: 5.2
Stable tag: 4.1.2
License: GPLv2 or later

XpoKit Kit is a lightweight customizer field generator plugins. Using this plugin you can create an customizer settings from your theme via filter.

== Description ==

XpoKit help you to create a theme custom customizer panel. Using `xpokit_customizer` filter you can create a custom panel. Inside the plugin core folder has a `Example.php` file. That can help you to create a new panel.

Major features in Xpo Kit include:
* Custom Separator field type for customizer
* Custom Layout field type for customizer
* Custom RGBA field type for customizer
* Custom switch field type for customizer
* Export customizer data
* Import customizer data
* A discard feature that outright blocks the worst spam, saving you disk space and speeding up your site.

== Installation ==

Upload the Xpo Kit plugin to your site, Activate it.

1, 2, 3: You're done!

== Changelog ==


= 1.0.0 =
*Release Date - 4th August, 2019

* Initial version submission
