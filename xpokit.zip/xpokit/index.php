<?php
// Hi there!  I am just a plugin, not much I can do when called directly.