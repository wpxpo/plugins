jQuery(document).ready(function($){ 'use strict';

    // Alpha Color Picker
    if( typeof alphaColorPicker != 'undefined' ){
        $( 'input.alpha-color-control' ).alphaColorPicker();
	}

    // Export Cuatomizer Data
    $(document).on('click', '#xpo-export-data', function (e) {
		e.preventDefault();
        window.location.href = xpo_kit.ajax_url+'?action=xpo_export_data';
	});

    // Import Cuatomizer Data
    $('body').on('click', '#xpo-import-data', function (e) {
		e.preventDefault();

		const file_data = $('#xpo-import-data-file').prop('files')[0],
			status = $('#xpo-import-status');

		if (typeof file_data == 'undefined') {
			status.addClass('xpo-import-error')
			status.text(xpo_kit.file_error);
			setTimeout(function () {
				status.removeClass('xpo-import-error')
				status.text('');
			}, 10000);
			return;
		}

		let form_data = new FormData(); 
		form_data.append('file', file_data);
    	form_data.append('name', file_data.name);
		form_data.append('action', 'xpo_import_data');
		
		$.ajax({
			url: xpo_kit.ajax_url,
			cache: false,
            contentType: false,
            processData: false,
			method: "POST",
			data: form_data,
			success: function (html) {
				if (html == 1) {
					status.addClass( 'xpo-import-success' )
					status.text( xpo_kit.import_success );
					setTimeout( function () { location.reload(); }, 2000);
					setTimeout( function () {
                        status.removeClass('xpo-import-success'); 
                        status.text('');
					}, 10000 );
				} else {
					status.addClass('eats-import-error')
					status.text(xpo_kit.import_error);
					setTimeout(function () {
						status.removeClass('eats-import-error')
						status.text('');
					}, 10000);
				}
			},
			error: function () {
				status.addClass('eats-import-error')
				status.text(eats_customizer.import_error);

				setTimeout(function () {
					status.removeClass('xpo-import-error')
					status.text('');
				}, 10000);
			}
		});
	});

	// Customizer Dependency

	$(window).load(function() {

		// Checkbox
		$( '.xpo-checkbox' ).each( function(){ customizerDepends(this); });
		$( '.xpo-checkbox-change' ).on( 'change', function(e){
			const select = $(this).parents('.xpo-checkbox');
			select.data('value', $(select).data('value') ? 0 : 1 )			
			customizerDepends(select);
		});

		// Select
		$( '.xpo-select' ).each( function(){ customizerDepends(this); });
		$( '.xpo-customizer-select' ).on( 'change', 'select', function(e){
			const select = $(this).parents('.xpo-select');
			select.data('value', $(this).val())			
			customizerDepends(select);
		});

		// Layout
		$( '.xpo-layout' ).each( function(){ customizerDepends(this); });
		$( '.xpo-customizer-layout' ).on( 'change', 'input', function(e){
			const select = $(this).parents('.xpo-layout');
			select.data('value', $(this).val())			
			customizerDepends(select);
		});


		function customizerDepends(that) {
			const condition = $(that).data('condition')
			const value = $(that).data('value')

			if(condition){
				condition.split(',').forEach( data => {
					data = data.split('#')
					if (data[1] == '=') {
						if (value == data[2]) { // is equal
							$('#customize-control-'+data[0]).show();
						} else {
							$('#customize-control-'+data[0]).hide();
						}
					} else if (data[1] == '!=') {
						if (value != data[2]) { // not equal
							$('#customize-control-'+data[0]).show();
						} else {
							$('#customize-control-'+data[0]).hide();
						}
					}
				});
			}
			
		}


	});


});
